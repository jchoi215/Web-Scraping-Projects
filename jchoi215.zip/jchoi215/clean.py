import os
import re
import sys

## =================================
##    COMMAND-LINE ERROR MESSAGES
## =================================
def errorMessage(type):
	if type == 1:
		print("\nPLEASE INPUT IN THIS FORM: \n\n   clean.py [filename].txt")
	elif type == 2:
		print("\nError:\n   Invalid filename found in 2ND commandline arguement")


## =================================
##         GET DATA FROM FILE
## =================================
def retrieve(filename):
	file = open(filename, 'r')
	rawData = file.read()
	file.close()
	return rawData


## =================================
##        CHECK IF SYM EXIST
## =================================
def contain(text, sym):
	for char in text: 
		if char == sym: return True
	return False


## =================================
##         SPLIT TOOLS
## =================================
def splitTail(name, sym):
	seg = name.split(sym)
	return seg[len(seg)-1]

def splitHead(name, sym):
	seg = name.split(sym)
	return seg[0]

def splitAll(data, delim):
	return data.split(delim)


## ========================================
##   CLEAN OUT ERROR IN CLASS LIST: PART 1
## ========================================
def clean(data):
	
	valid = []

	data = data.lower()
	data = data.replace('sceintific', 'scientific')
	data = data.replace('artifical', 'artificial')
	data = re.sub(r"&[ ]", 'and ', data)
	data = data.split("\n")

	for row in data:
		try:
			name, tClass = row.split('  - ')
			valid.append(extractLastName(name) + "  - " + filterClass(tClass))
			valid = sorted(valid)
		except:
			valid = sorted(valid)
			return valid

	return valid


## ========================================
##   CLEAN OUT ERROR IN CLASS LIST: PART 2
## ========================================
def fixClass(data):
	
	FINAL_DATA = []
	limit = len(data)

	for x in range(0, limit):
		
		nameA, datA = data[x  ].split("  - ")
		datA = datA.split("|")

		if x+1 < limit-1:
			nameB, datB = data[x+1].split("  - ")
			datB = datB.split("|")

			if nameA == nameB:

				for i in datA:
					
					Found = False
					for j in datB:
						if i == j: 
							Found = True
							break
							
					if not Found: datB.append(i)

					data[x+1] = remerge(nameB, sorted(datB))
			
			else: 
				FINAL_DATA.append(data[x])

	return FINAL_DATA


## ========================================
##   CLEAN OUT ERROR IN GENERAL COLLECTION
## ========================================
def filterClass(tClass):
	row = splitAll(tClass, "|")
	row = sorted(row)

	outCounter = 0
	outLimit = len(row)
	refinedClass = ""

	for x in row:
		refinedRow = ""
		midSplit = x.split(" ")
		
		counter = 0
		limit = len(midSplit)
		
		for y in midSplit:
			y = re.sub(r"intro[.]", 'introduction', y)
			y = re.sub(r"intro$", 'introduction', y)
			if contain(y, 'z'):
				if not (y == "visualization" or y == "optimization" or y == "citizens" or y == "velazquez"):
					y = y.replace("z", "s")
			refinedRow += y
			if counter < limit-1: refinedRow += " "
				
			counter += 1
		
		refinedClass += refinedRow
		if outCounter < outLimit-1: refinedClass+= "|"
			
		outCounter+= 1
	return refinedClass


## =================================
##   CLEAN OUT ERROR IN LAST NAME
## =================================
def extractLastName(name):

	if contain(name, ','):
		try:
			name = splitHead(name, ', ')
			name = splitTail(name, ' ')
		except:
			name = name 
	elif contain(name, '.'):
		try:
			name = splitTail(name, '.')
			name = splitTail(name, ' ')
		except:
			name = name 
	else:
		name = splitTail(name, ' ')

	return name


## =================================
##  WRITE DATA TO GIVEN FILE NAME
## =================================
def Export(file, info):
	targetFile = open(file,"w") 
	
	cnt = 0
	limit = len(info)

	for x in info:
		targetFile.write(x)
		
		if cnt < limit - 1: targetFile.write("\n")
	targetFile.close()
			

## =================================
##  CONVERT BACK TO PROPER FORM
## =================================
def remerge(name, data):

	cnt = 0
	row = name + "  - ";
	limit = len(data)

	for x in data:
		row += x

		if cnt < limit-1: row += "|"
			
		cnt += 1
	return row


## =================================
##       HEART OF THE CODE
## =================================

if len(sys.argv) > 1:
	if os.path.isfile(sys.argv[1]):
		print(">>> CLEANING UP: {}".format(sys.argv[1]))
		data = fixClass(clean(retrieve(sys.argv[1])))
		Export("cleaned.txt", data)
		print(">>> WRITE TO: cleaned.txt ... [COMPLETE]")
	else: errorMessage(2)
else: errorMessage(1)


