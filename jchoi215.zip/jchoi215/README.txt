Solution Explanation for clean.py:

	Error Checking given file in the command-line input:
		If length of the input argument is longer than 2 and it is a readable continue process
		Other wise throw error message and stop
	Extracting the last name:
		If it contains a comma, split the name and take the front portion of the name
		If it contains a period (special case) take the last portion from the name
		Lastly if it does not have any comma or period, just split and take the end portion
	Issues with clean up classes:
		�There were spelling mistakes, missed abbreviations�			
		
		RULES AND REGULATIONS: 
		0. All words are changed to lower case to prevent word mismatch with upper and lower case
		1. only accepted z word: visualization / opimization / citizens / velazquez
   			all other words containing 'z' are converted to 's'
		2. special spelling correction for:

			[arifical]   ->  [artificial]
			[sceintific] ->  [scientific]
			[intro]      ->  [introduction]
			[intro.]     ->  [introduction]
			[&]          ->  [and]
		
		I was hoping to make it more generalized but without using a dictionary it
		Was going to be rather difficult so these words were replaced by direct manipulation thus
		Accuracy will drop when using larger text files. 

	Error that could arise from this code: 
		* Invalid command input could potentially
		* If the given file exist but is either completely missin data or really odd splits COULD potentially break the code.
		* Classes that are not corrected by the "RULES AND REGULATIONS" above will remain dirty data.
		* Spelling issues are difficult to catch, next time I will try using dictionary to fix the words instead.

Solution Explanation for query.py:

	Error Checking given file in the command-line input:

		Similar to clean.py approach but checks for length of argument of 3 or more

	Solution Q1: Finding Unique Class:

		Extract all the classes, sort the data, and move down the list to check
		Prior and current. If the two are the same then it must NOT be unique thus
		Go ahead and ignore the data. If they are different store that class into a Unique 
		Class list. P.S must have clean data and must be sorted for this to work. The run
		Time is rather quick as repetition of class is rather low.

	Solution Q2: Finding Professor class

		For this I honestly did not what input format the user would use
		Thus, I split the data by SPACE, PERIOD or Comma then checked for
		All the split words. Look up time is O (n log n) by using binary search, which
		Returns -1 if no solution is found. The weakness of this method is that search target
		Of �Yu Troy� would show a list of classes taught by professor Yu and also by Prof. Troy.
		But I feel justified as user input is rather difficult to comprehend.

	Solution Q3: Find 2 Professor with similar classes by using Jaccard distance

		When extracting the data first time around, I broke the it into list of: names, classes, class count and full data. Then looped over the count list to find all the index with classes more than 5. 
		Stored those as valid set. Then looped over the professor and their classes with other professors and retrieved the Jaccard value. Which I checked for Max value and printed out the 2 professors
		That have the greatest Jaccard distance values. If there happen to be a case where distance are the same, it will list all the cases instead of just picking one.

	Error that could arise from this code: 
		
		if the given file is a valid text document but is not cleaned or MISSING in data it could potentially cause the program to crash
	
	


