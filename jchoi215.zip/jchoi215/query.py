import sys
import os


## =================================
##    COMMAND-LINE ERROR MESSAGES
## =================================
def errorMessage(type):
	if type == 1:
		print("\nPLEASE INPUT IN THIS FORM: \n\n   query.py [file].txt target_name")
	elif type == 2:
		print("\nError:\n   Invalid filename found in 2ND commandline arguement")
	elif type == 3: 
		return


## =================================
##         GET DATA FROM FILE
## =================================
def retrieve(filename):
	file = open(filename, 'r')
	rawData = file.read()
	file.close()
	return rawData


## =================================
##   FOR FINDING INTERSECTS & UNION
##   Took reference from # 30
## =================================
def countIntersect(a, b):
	return  len(list(set(a) & set(b)))

def countUnion(a, b):
	return  len(list(set(a) | set(b)))


## =================================
##      FIND JACCARD DISTANCE
## =================================
def toJCoefficient(listA, listB):
	return float(countIntersect(listA, listB)) / countUnion(listA, listB) 


## =================================
##       FOR TARGETS SEARCH
##  TOOK REFERENCE FROM # 32 && 33 
## =================================
def binarySearch(gList, target):
	
	searchIndex = -1
	
	start = 0
	end = len(gList)-1

	while start <= end and searchIndex == -1:
		mid = (start + end) // 2

		if gList[mid] == target: searchIndex = mid
		else: 
			if target < gList[mid]: end = mid-1
			else: start = mid+1

	return searchIndex


## =================================
##   FOR QUICKER DATA MANIPULATION
## =================================
def Split_Name_Data(data):
	
	name   = [] 
	roster = []
	count  = []
	classL = []

	for row in data:
		try:
			a, b = row.split("  - ")
			b = b.split("|")
			classL.append(b)
			name.append(a)
			count.append(len(b))
			
			for x in b:
				roster.append(x)
		except: pass
			
	return name, classL, roster, count
	

## =================================
##     Extract Valid Data Jaccard
## =================================
def ExtractValidJaccard(nameL, classL, countL):

	vName  = []
	vClass = []

	for x in range(len(countL)):
		if countL[x] > 4:
			vName.append(nameL [x])
			vClass.append(classL[x])
	
	return vName, vClass


## =================================
##   FIND COUNT OF UNIQUE CLASSES
## =================================
def Q1(classList):
	
	Unique = []
	raw = sorted(classList)
	limit = len(raw)

	for x in range(1 , limit):
		if not raw[x-1] == raw[x]:
			Unique.append(raw[x-1])

	if not raw[limit-1] == Unique[len(Unique)-1]:
		Unique.append(raw[limit-1]) 

	print("\n Q1: How many distinct courses does this dataset contain?\n")
	print('   Unique class count:  {}\n'.format(len(Unique)))


## =================================
##   FIND CLASSES TAUGHT BY: x 
## =================================
def Q2(nameL, data, pName):
	print(' Q2: List all courses taught by Professor {}'.format(pName))

	Found = False
	prof = pName.replace(',', ' ').replace('.', ' ').lower().split(" ")

	for sName in prof:
		index = binarySearch(nameL, sName)

		if not index == -1:

			print('\n   Under the lastname of Professor [ {} ] these classes were found: '.format(sName.title()))

			Found = True
			a, classList = data[index].split("  - ")
			classList = classList.split("|")			

			FinalPrint = ""
			end = len(classList)
			for index in range(end):
				FinalPrint += classList[index]

				if not index == end-1:
					FinalPrint += ",\n   "
			
			print("\n   {}".format(FinalPrint.title()))

	if not Found: print("\n   Professor by the name of [ {} ] could not be found".format(pName))	


## =================================
##  Find 2 Prof w/ highest Jaccard
## =================================
def Q3(nameL, classL, countL):

	print("\n Q3: Find professors with most aligned teaching interests: ")

	vName, vClass = ExtractValidJaccard(nameL, classL, countL)

	ProfA = []
	ProfB = []
	coefL = []
	start = 0
	best  = -1.0
	limit = len(vClass)
	
	for i in range(limit):
		for j in range(start, limit):
			if not i == j:
				coef = toJCoefficient(vClass[i] , vClass[j])
				
				if coef >= best:
					best = coef
					ProfA.append(vName[i])
					ProfB.append(vName[j])
					coefL.append(coef)
		start += 1

	highest = max(coefL)
	for x in range(len(coefL)):
		if coefL[x] == highest:
			print("\n   Prof. {}\n   Prof. {}".format(ProfA[x].title(), ProfB[x].title()))
			print("   Jaccard Distance: {}".format(coefL[x]))


## =================================
##      HEART OF THE CODE
## =================================
if len(sys.argv) > 2:
	if os.path.isfile(sys.argv[1]):

		data = retrieve(sys.argv[1])
		data = data.split("\n")
		
		nameL, classL, rosterL, countL = Split_Name_Data(data)

		Q1(rosterL)
		Q2(nameL, data, sys.argv[2])
		Q3(nameL, classL, countL)

	else: errorMessage(2)	
else: errorMessage(1)	