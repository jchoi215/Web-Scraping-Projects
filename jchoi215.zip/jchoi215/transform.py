import urllib.request 
from bs4 import BeautifulSoup
import csv


# ==================================
#       Delim values
# ==================================
rExpres = ['!', ', ', ' !', ' ']


# ==================================
# check if there exist a number in the string
# ==================================
def containNum(text):
	return any(char.isdigit() for char in text)


# ==================================
#   Scrape the Data from the page
# ==================================
def scrape_page(url):
	raw_data = urllib.request.urlopen(url)
	raw_data = BeautifulSoup(raw_data, "html.parser") 
	return raw_data


# ==================================
# Seperate string by delim and return HEAD
# ==================================
def frontSplit(text, delim):
	try:
		a, b = text.split(delim, 1)
		return a
	except:
		return text


# ==================================
# Seperate string by delim & return TAIL
# ==================================
def endSplit(text, delim):
	try:
		a, b = text.split(delim, 1)
		return b
	except: 
		return text


# ==================================
#       Parse raw data
# ==================================
def spliter(x, text):
	return {
		0: endSplit(text, rExpres[0]),
		1: endSplit(text, rExpres[1]),
		2: frontSplit(text, rExpres[2]),
		3: frontSplit(endSplit(text, rExpres[0]), rExpres[3]),
		4: frontSplit(text, rExpres[2]),
		5: frontSplit(text, rExpres[2]),
	}[x]


# ==================================
# ADD Header, write data in CSV format
# ==================================
def writeToCSV(data):
	
	with open("transformed.csv", "w") as csv_file:
		csv_app = csv.writer(csv_file)
		csv_app.writerow(["Game", "Year", "Winning", "Score", "Losing team", "Venue"])

		limit = len(data)

		for x in range(0, limit, 6):
			if x+3 < limit:
				if containNum(data[x+3]):
					csv_app.writerow([data[x], data[x+1], data[x+2], data[x+3], data[x+4], data[x+5]])


# ==================================
# Clean out the noise from data
# ==================================
def filter(data):
	
	cntr= 0
	finalData = []

	tbl = data.find_all('table', class_ = 'wikitable sortable')[1]

	for line in tbl.find_all('td'):
		if cntr < 6: 
			refined = spliter(cntr, line.text)
			finalData.append(refined)

		cntr += 1
		if cntr == 9:
			cntr = 0

	return finalData


# ==================================
# CORE GUIDING PROCESS 
# ==================================
site = 'https://en.wikipedia.org/wiki/List_of_Super_Bowl_champions'
print("COLLECTING DATA...")
writeToCSV( filter( scrape_page(site) ) )
print("WRITE TO CSV [COMPLETE]")